import express from 'express';
import { invitationForReferral, assignReferral, getDataForTree, createPaymentRequest, handlePaymentApproval } from '../controllers/referral.controller';

const router = express.Router();

router.post('/invite', invitationForReferral);
router.post('/accept/:token', assignReferral); // Assuming you want to handle acceptance as well
router.post('/tree' , getDataForTree)
router.post('/payment-request', createPaymentRequest);
router.post('/payment-request/handle', handlePaymentApproval);

export default router;