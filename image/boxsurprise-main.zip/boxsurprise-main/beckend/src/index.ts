import express, { Request, Response } from "express";
import dotenv from "dotenv";
import * as Sentry from "@sentry/node";
import dbConnect from "./config/db";
import authRoutes from './routes/auth.route'
import withdrawRoutes from './routes/withdraw.route'
import referralRoutes from './routes/user.referral'
import postingRoutes from './routes/post.route'
import cookieParser from "cookie-parser";
import cors from "cors"; 



if (process.env.NODE_ENV === 'production') {
  dotenv.config({ path: '.env.production' });
} else {
  dotenv.config();  // default .env
}
// Database Connection
let isDbConnected = false; // <-- Add this at the top, after `dotenv.config()`

// Database Connection
dbConnect()
  .then(() => {
    console.log("Database connected successfully");
    isDbConnected = true; // <-- Set it to true when connected
  })
  .catch((err) => {
    console.error("Database connection error:", err);
    isDbConnected = false;
  });
const app = express();
// app.use(express.json());

console.log('CLIENT_URI:', process.env.CLIENT_URI);
// const corsOpts = {
//   origin: '*',

//   methods: [
//     'GET',
//     'POST',
//     'OPTIONS',
//   ],

//   allowedHeaders: [
//     'Content-Type',
//   ],
// };
// app.use(cors({
//   origin: 'http://localhost:5173', // Your frontend origin exactly
//   credentials: true, // Allow cookies
// }));

// 1️⃣ CORS config define karo
const allowedOrigins = ['http://localhost:5173', 'https://boxsurprise.onrender.com'];

interface CorsOptions {
  origin: (origin: string | undefined, callback: (err: Error | null, allow?: boolean) => void) => void;
  credentials: boolean;
  methods: string[];
  allowedHeaders: string[];
}

const corsOptions: CorsOptions = {
  origin: function (origin: string | undefined, callback: (err: Error | null, allow?: boolean) => void): void {
    console.log("Incoming Origin:", origin);
    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(null, false);
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
};

// 2️⃣ Sabse pehle CORS middleware lagao
app.use(cors(corsOptions));

// 3️⃣ Fir ye line lagao — ye bhi CORS ke sath hi chalegi (OPTIONS requests ke liye)
app.options('*', cors(corsOptions), (_req, res) => {
  res.sendStatus(200);
});   // 👈 bhoolna mat


app.use(express.json()); // Middleware to parse JSON requests
app.use(cookieParser())

// Routes
app.get('/', (_req: Request, res: Response) => {
  res.json({ 
    message: "API is WORKING", 
    database: isDbConnected ? "Connected" : "Not Connected" 
  });
});

app.get('/debug-sentry', function mainHandler(_req: Request, _res: Response) {
  throw new Error("My First Sentry Error!")
})

app.use('/api/auth' , authRoutes)
app.use('/api/referral', referralRoutes)
app.use("/api/easypaisa", withdrawRoutes);
app.use("/api/post", postingRoutes);

Sentry.setupExpressErrorHandler(app)

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));


