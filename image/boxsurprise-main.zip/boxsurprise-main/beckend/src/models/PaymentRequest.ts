// models/PaymentRequest.ts
import mongoose, { Document, Schema } from 'mongoose';

export interface PaymentRequestDocument extends Document {
  user: mongoose.Types.ObjectId;
  amount: number; // optional (agar admin specify kare)
  status: 'pending' | 'approved' | 'rejected';
  createdAt: Date;
}

const paymentRequestSchema = new Schema<PaymentRequestDocument>(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    amount: { type: Number, default: 0 },
    status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
  },
  { timestamps: true }
);

const PaymentRequest = mongoose.model<PaymentRequestDocument>('PaymentRequest', paymentRequestSchema);
export default PaymentRequest;
