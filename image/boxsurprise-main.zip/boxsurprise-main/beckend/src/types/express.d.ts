declare namespace Express {
    export interface Request {
      user?: UserDocument; // or you can specify the type of `user` based on your schema
    }
  }