"use client"
import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { useAppDispatch } from "../hooks"
import { setUser } from "../features/auth/authSlice"
import axios from "axios";

const VerifyUser = () => {
  const dispatch = useAppDispatch()
  const [token, setToken] = useState("")
  const [message, setMessage] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const navigate = useNavigate()

  const handleVerify = async () => {
    setError("");
    setMessage("");
  
    if (!token || token.trim() === "") {
      setError("Please enter a verification code");
      return;
    }
  
    setIsLoading(true);
  
    try {
      const apiBaseUrl = window.location.hostname === 'localhost'
        ? import.meta.env.VITE_LOCAL_URI
        : import.meta.env.VITE_SERVER_URI;
  
      // Timeout config (15 sec)
      const axiosInstance = axios.create({
        baseURL: apiBaseUrl,
        timeout: 15000,
        withCredentials: true, // Important for cookies/session
        headers: {
          'Content-Type': 'application/json'
        }
      });
  
      const response = await axiosInstance.post('/api/auth/verify-email', { code: token });
  
      const data = response.data;
  
      dispatch(
        setUser({
          id: data.user.id,
          name: data.user.name,
          email: data.user.email,
          phone: data.user.phone,
          referralId: data.user.referralId || null,
          createdAt: data.user.createdAt,
          partOfReferral: data.user.partOfReferral,
        }),
      );
  
      setMessage(data.message || "Verification successful!");
  
      setTimeout(() => {
        navigate("/dashboard");
      }, 1500);
  
    } catch (err) {
      if (axios.isAxiosError(err)) {
        if (err.code === 'ECONNABORTED') {
          setError("Request timed out. Please try again.");
        } else if (err.response) {
          const status = err.response.status;
          const message = err.response.data?.message;
  
          if (status === 400) setError(message || "Invalid verification code");
          else if (status === 401) setError(message || "Unauthorized access");
          else if (status === 404) setError(message || "Verification code not found");
          else if (status === 410) setError(message || "Verification code has expired");
          else setError(message || `Server error (${status})`);
        } else {
          setError("Failed to verify. Please try again.");
        }
      } else {
        setError("An unexpected error occurred. Please try again.");
      }
      console.error("Verification error:", err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-green-100 to-blue-100 p-4">
      <div className="bg-white shadow-xl rounded-2xl w-full max-w-md p-8 transition-all duration-300 ease-in-out">
        <h2 className="text-3xl font-bold text-center text-blue-700 mb-2">User Verification</h2>
        <p className="text-center text-gray-600 mb-6">
          Please enter your verification number below. This helps us confirm your identity and keep your account secure.
        </p>

        <label className="block text-sm font-medium text-gray-700 mb-1">Verification Code</label>
        <input
          type="number"
          value={token}
          onChange={(e) => setToken(e.target.value)}
          placeholder="e.g. 123456"
          className={`w-full px-4 py-2 mb-4 border ${error ? "border-red-500" : "border-gray-300"} rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 transition`}
          disabled={isLoading}
        />

        {error && <div className="mb-4 text-sm text-red-600 font-medium">{error}</div>}

        <button
          onClick={handleVerify}
          disabled={isLoading}
          className={`w-full ${isLoading ? "bg-blue-400 cursor-not-allowed" : "bg-blue-600 hover:bg-blue-700"} text-white font-semibold py-2 px-4 rounded-lg transition duration-200 flex justify-center items-center`}
        >
          {isLoading ? (
            <>
              <svg
                className="animate-spin -ml-1 mr-3 h-5 w-5 text-white"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
              >
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                ></path>
              </svg>
              Verifying...
            </>
          ) : (
            "Verify Now"
          )}
        </button>

        {message && <div className="mt-5 text-center text-sm text-green-600 font-medium">{message}</div>}
      </div>
    </div>
  )
}

export default VerifyUser
