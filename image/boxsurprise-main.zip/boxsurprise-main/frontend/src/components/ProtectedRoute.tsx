import { Navigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { JSX } from 'react';

export default function ProtectedRoute({ children }: { children: JSX.Element }) {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { user } = useSelector((state: any) => state.auth);

  if (!user) return <Navigate to="/login" />;
  if (!user.partOfReferral) return <Navigate to="/contact" />;

  return children;
}
