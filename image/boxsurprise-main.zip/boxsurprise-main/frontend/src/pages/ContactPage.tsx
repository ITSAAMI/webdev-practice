import { useSelector } from 'react-redux';
import { useState } from 'react';
import axios from 'axios';
import { MessageCircle, Loader2 } from 'lucide-react';

export default function ContactPage() {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { user } = useSelector((state: any) => state.auth);
  const [link, setLink] = useState('');
  const [loading, setLoading] = useState(false);

  const whatsappNumber = '923001234567'; // <-- Replace with your WhatsApp number (92XXXXXXXXXX)

  const requestReferral = async () => {
    try {
      setLoading(true);
      const apiBaseUrl = window.location.hostname === 'localhost'
        ? import.meta.env.VITE_LOCAL_URI
        : import.meta.env.VITE_SERVER_URI;

      await axios.post(`${apiBaseUrl}/api/referral/payment-request`, {
        userId: user._id,
      });

      const generatedLink = `${window.location.origin}/referral-request/${user._id}`;
      setLink(generatedLink);
    } catch (err) {
      console.error(err);
      alert('Request already pending or failed');
    } finally {
      setLoading(false);
    }
  };

  const whatsappMessage = encodeURIComponent(`I want to buy this product. Kindly give credentials for it.\nHere is my referral link: ${link}`);
  const whatsappLink = `https://wa.me/${whatsappNumber}?text=${whatsappMessage}`;

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
      <div className="bg-white rounded-xl shadow-xl p-8 max-w-md w-full text-center">
        <h1 className="text-2xl font-bold text-gray-800 mb-4">Join Our Referral Program</h1>
        <p className="text-gray-600 mb-6">
          You need to make a payment of <span className="font-semibold">Rs.5000</span> to become part of our referral network. Please contact us to proceed.
        </p>

        {!link ? (
          <button
            onClick={requestReferral}
            className="bg-blue-500 text-white py-3 px-6 rounded-full shadow hover:bg-blue-600 transition flex items-center justify-center gap-2 w-full"
            disabled={loading}
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
            Request to Buy Product (5000 PKR)
          </button>
        ) : (
          <>
            <div className="bg-gray-100 rounded-lg p-4 text-left text-sm text-gray-700 mb-4 break-all">
              <p className="font-semibold mb-1">Referral Link:</p>
              <p>{link}</p>
            </div>

            <a
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-green-500 text-white py-3 px-6 rounded-full shadow hover:bg-green-600 transition w-full justify-center"
            >
              <MessageCircle className="w-5 h-5" />
              Contact on WhatsApp
            </a>

            <p className="text-xs text-gray-500 mt-3 italic">
              Click the button to send link & message directly to admin.
            </p>
          </>
        )}
      </div>
    </div>
  );
}
